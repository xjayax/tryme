﻿namespace RSBot.Core;

public enum GameClientType : byte
{
    Japanese_Old,
    Thailand,
    Vietnam,
    Taiwan,
    Vietnam193,
    Vietnam274,
    Chinese,
    Global,
    Turkey,
    VTC_Game,
    Korean,
    RuSro,
    Rigid
}