﻿namespace RSBot.Core.Objects;

public enum InteractMode
{
    None = 0,
    P2P = 2,
    P2N_TALK2 = 3, // newer clients
    P2N_TALK = 4,
    OPNMKT_DEAL = 6
}