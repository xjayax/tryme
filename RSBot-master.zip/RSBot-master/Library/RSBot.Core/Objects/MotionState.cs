﻿namespace RSBot.Core.Objects;

public enum MotionState
{
    None = 0,
    Walking = 2,
    Running = 3,
    Sitting = 4
}