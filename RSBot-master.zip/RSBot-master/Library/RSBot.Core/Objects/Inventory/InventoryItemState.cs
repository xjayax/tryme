﻿namespace RSBot.Core.Objects;

public enum InventoryItemState
{
    Inactive = 1,
    Summoned = 2,
    Active = 3,
    Dead = 4
}