﻿namespace RSBot.Core.Objects;

public enum MovementType
{
    Walking = 0,
    Running = 1
}