﻿namespace RSBot.Core.Objects;

public enum ActionTarget
{
    None = 0,
    Entity = 1,
    Area = 2
}