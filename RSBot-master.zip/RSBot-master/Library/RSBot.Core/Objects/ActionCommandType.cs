﻿namespace RSBot.Core.Objects;

public enum ActionCommandType : byte
{
    Execute = 1,
    Cancel = 2
}