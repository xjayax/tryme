﻿namespace RSBot.Core.Objects;

public enum PvpFlag
{
    None = 0,
    Red = 1,
    Gray = 2,
    Blue = 3,
    White = 4,
    Gold = 5
}