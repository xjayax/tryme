﻿namespace RSBot.Core.Objects;

public enum StoreType
{
    PotionTrader,
    WeaponTrader,
    ProtectorTrader,
    CosTrader,
    AccessoryTrader
}