﻿namespace RSBot.Core.Objects;

public enum ActionType : byte
{
    Attack = 1,
    Pickup = 2,
    Trace = 3,
    Cast = 4,
    Dispel = 5
}