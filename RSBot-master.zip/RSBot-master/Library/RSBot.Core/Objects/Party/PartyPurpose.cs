﻿namespace RSBot.Core.Objects.Party;

public enum PartyPurpose : byte
{
    Hunting,
    Quest,
    Trade,
    Thief
}