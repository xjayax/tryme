﻿namespace RSBot.Core.Objects.Party;

internal enum PartyMemberUpdateType
{
    NameRefObjID = 1,
    Level = 2,
    HPMP = 4,
    Mastery = 8,
    Position = 32,
    Guild = 64
}