﻿namespace RSBot.Core.Objects;

public enum BattleState
{
    InPeace = 0,
    InBattle = 1
}