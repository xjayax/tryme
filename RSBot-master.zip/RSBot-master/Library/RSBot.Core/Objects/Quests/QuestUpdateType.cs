﻿namespace RSBot.Core.Objects.Quests;

public enum QuestUpdateType : byte
{
    Add = 1,
    Update = 2,
    Remove = 3,
    Abandon = 4
}