﻿namespace RSBot.Core.Objects.Cos;

public class JobTransport : Cos
{
}