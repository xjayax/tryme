﻿namespace RSBot.Core.Objects;

public enum JobType
{
    None = 0,
    Trade = 1,
    Thief = 2,
    Hunter = 3
}