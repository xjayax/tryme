﻿namespace RSBot.Core.Objects;

public enum ActionState : byte
{
    Begin = 1,
    End = 2,
    Error = 3
}