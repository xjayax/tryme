﻿namespace RSBot.Core.Objects;

public enum ScrollState
{
    Cancel = 0,
    NormalScroll = 1,
    ThiefScroll = 2 //able to move
}