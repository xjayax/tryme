﻿namespace RSBot.Core.Objects;

public enum AmmunitionType
{
    None = 0,
    Arrow = 1,
    Bolt = 2
}