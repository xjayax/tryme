﻿namespace RSBot.Core.Objects;

public enum ScrollMode
{
    None = 0,
    ReturnScroll = 1,
    BanditReturnScroll = 2
}