﻿namespace RSBot.Core.Objects;

public enum ExchangeUpdateType : byte
{
    Item = 1,
    Gold = 2
}