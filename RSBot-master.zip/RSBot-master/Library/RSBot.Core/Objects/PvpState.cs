﻿namespace RSBot.Core.Objects;

public enum PvpState
{
    None = 0,
    Purple = 1,
    Red = 2,
    Unknown = 3 // newer clients
}