﻿namespace RSBot.Core.Objects;

public enum LifeState
{
    Alive = 0x01,
    Dead = 0x02
}