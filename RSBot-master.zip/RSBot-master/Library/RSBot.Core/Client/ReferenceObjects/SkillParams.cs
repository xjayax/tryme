﻿namespace RSBot.Core.Client.ReferenceObjects;

public enum PrimarySkillParam: int
{
    Meele = 0,
    Ranged = 1,
    Reserved = 2, //Unknown / not used
    Buff = 3,
    Passive = 4
}