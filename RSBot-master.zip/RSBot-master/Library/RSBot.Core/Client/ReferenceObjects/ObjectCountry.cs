﻿namespace RSBot.Core.Client.ReferenceObjects;

public enum ObjectCountry : byte
{
    Chinese = 0,
    Europe = 1,
    Islam = 2,
    Unassigned = 3
}