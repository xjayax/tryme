﻿namespace RSBot.Core.Client.ReferenceObjects;

public enum ObjectGender : byte
{
    Female = 0,
    Male = 1,
    Neutral = 2
}