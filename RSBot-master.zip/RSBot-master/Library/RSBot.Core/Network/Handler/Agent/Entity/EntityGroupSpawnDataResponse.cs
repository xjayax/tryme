﻿namespace RSBot.Core.Network.Handler.Agent.Entity;

internal class EntityGroupSpawnDataResponse : IPacketHandler
{
    /// <summary>
    ///     Gets or sets the opcode.
    /// </summary>
    /// <value>
    ///     The opcode.
    /// </value>
    public ushort Opcode => 0x3019;

    /// <summary>
    ///     Gets or sets the destination.
    /// </summary>
    /// <value>
    ///     The destination.
    /// </value>
    public PacketDestination Destination => PacketDestination.Client;

    /// <summary>
    ///     Handles the packet.
    /// </summary>
    /// <param name="packet">The packet.</param>
    public void Invoke(Packet packet)
    {
        if (Game.SpawnInfo == null)
            return; //No active spawn!

        Game.SpawnInfo.Packet.WriteBytes(packet.GetBytes());
    }
}