﻿using RSBot.Core.Event;

namespace RSBot.Core.Network.Handler.Agent.CharacterSelection;

internal class CharacterSelectionJoinRequest : IPacketHandler
{
    /// <summary>
    ///     Gets or sets the opcode.
    /// </summary>
    /// <value>
    ///     The opcode.
    /// </value>
    public ushort Opcode => 0x7001;

    /// <summary>
    ///     Gets or sets the destination.
    /// </summary>
    /// <value>
    ///     The destination.
    /// </value>
    public PacketDestination Destination => PacketDestination.Server;

    /// <summary>
    ///     Handles the packet.
    /// </summary>
    /// <param name="packet">The packet.</param>
    public void Invoke(Packet packet)
    {
        var characterName = packet.ReadString();

        PlayerConfig.Load(characterName);

        EventManager.FireEvent("OnEnterGame");
    }
}