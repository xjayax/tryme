﻿namespace RSBot.Core.Network;

public enum PacketDestination
{
    Server = 1,
    Client = 2
}