﻿using RSBot.NavMeshApi.Mathematics;

namespace RSBot.NavMeshApi.Dungeon;

public class DungeonColObj
{
    public CircleF Circle { get; set; }
    public string Name { get; set; }
}